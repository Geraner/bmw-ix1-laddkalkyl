# BMW iX1 laddkalkyl Europa

En enkel laddkalkyl för BMW iX1-ägare i Sverige som kör i Europa.

## Viktig ändring: OS-oberoende valutakurser

Webbappen hämtar inte längre Riksbankens API direkt från användarens webbläsare. I stället uppdaterar GitHub Actions filen `rates.json` via Riksbankens API. Själva webbappen läser sedan `rates.json` från samma GitHub Pages-domän.

Detta är mer robust för Safari/iPhone/Mac och andra webbläsare, eftersom appen inte längre är beroende av direkta cross-origin-anrop från klienten.

## Funktioner

- Snabbknappar för vanliga laddpriser
- Snabbknappar för start-SoC och mål-SoC
- Sammanfattningsrad i klartext
- Hopfällbara block för valutakurser och manuella valutakurser
- PWA-stöd med manifest, appikon och service worker
- `rates.json` som lokal valutakurskälla
- GitHub Actions workflow för automatisk uppdatering av valutakurser

## Efter uppladdning

1. Ladda upp alla filer till repositoryt, inklusive `.github/workflows/update-rates.yml`, `scripts/fetch-rates.mjs` och `rates.json`.
2. Gå till **Actions** i repositoryt.
3. Om GitHub frågar, aktivera workflows.
4. Kör workflowt **Update exchange rates** manuellt första gången via **Run workflow**.
5. Kontrollera att `rates.json` har uppdaterats.

## Säkerhetsåtgärder

- Content Security Policy i `index.html`
- Referrer-policy
- Inga externa JavaScript-bibliotek
- Inga cookies och ingen tracking
- Ingen användning av `innerHTML` för användarstyrt innehåll
- Numeriska gränser för pris, SoC, batteristorlek, förbrukning och valutakurser
- Lokal fallback via `localStorage` om `rates.json` inte kan hämtas
- GitHub Actions hämtar Riksbankens API server-side och skriver statisk `rates.json`

## Begränsningar

Beräkningarna är ungefärliga. Laddförluster, kortpåslag, parkeringsavgifter, blockeringstaxa och operatörernas prisändringar kan påverka slutkostnaden.
